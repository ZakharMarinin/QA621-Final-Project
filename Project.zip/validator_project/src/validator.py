import json
from pathlib import Path
from typing import List, Dict, Any
from .rules import ValidatorRule, TypeRule, RangeRule, RegexRule
from .exceptions import InvalidConfigError
from .models import RuleConfig, ValidationResult, ValidationError
from .utils import measure_time, retry_on_error

class Validator:
    _rule_map = {
        "type": TypeRule,
        "range": RangeRule,
        "regex": RegexRule,
    }

    @classmethod
    def _build_rule(cls, config: RuleConfig) -> ValidatorRule:
        rule_class = cls._rule_map.get(config.rule_type)
        if rule_class is None:
            raise InvalidConfigError(f"Неизвестный тип правила: {config.rule_type}")
        params = config.params.copy()
        if config.rule_type == "type":
            type_name = params.pop("expected_type", "str")
            mapping = {"int": int, "float": float, "str": str, "bool": bool}
            expected_type = mapping.get(type_name, str)
            params["expected_type"] = expected_type
        return rule_class(**params)

    @measure_time
    def __init__(self, rules_config: List[RuleConfig]):
        self._rules_by_field: Dict[str, List[ValidatorRule]] = {}
        for rc in rules_config:
            rule = self._build_rule(rc)
            self._rules_by_field.setdefault(rc.field_name, []).append(rule)

    def validate_row(self, row: Dict[str, Any], row_index: int) -> List[ValidationError]:
        errors: List[ValidationError] = []
        for field_name, rules in self._rules_by_field.items():
            if field_name not in row:
                continue
            value = row[field_name]
            for rule in rules:
                errors.extend(rule.validate(value, row_index, field_name))
        return errors

    @retry_on_error(max_retries=3)
    def validate_data(self, data: List[Dict[str, Any]]) -> ValidationResult:
        result = ValidationResult(total_rows=len(data))
        for idx, row in enumerate(data):
            row_errors = self.validate_row(row, idx)
            result.errors.extend(row_errors)
        return result