from dataclasses import dataclass, field
from typing import List, Any, Optional

@dataclass
class RuleConfig
    field_name str
    rule_type str  # type, range, regex
    params dict = field(default_factory=dict)

@dataclass
class ValidationError
    row_index int
    field_name str
    message str

@dataclass
class ValidationResult
    total_rows int
    errors List[ValidationError] = field(default_factory=list)
    warnings List[str] = field(default_factory=list)