import pytest
from src.rules import TypeRule, RangeRule
from src.models import ValidationError

def test_type_rule_success():
    rule = TypeRule(expected_type=int)
    errors = rule.validate(10, row_index=0, field_name="age")
    assert len(errors) == 0

def test_type_rule_fail():
    rule = TypeRule(expected_type=int)
    errors = rule.validate("ten", row_index=1, field_name="age")
    assert len(errors) == 1
    assert "Ожидался тип int" in errors[0].message

def test_range_rule_out_of_bounds():
    rule = RangeRule(min_val=0, max_val=100)
    errors = rule.validate(-1, row_index=2, field_name="score")
    assert len(errors) == 1