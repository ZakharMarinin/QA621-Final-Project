import re
from abc import ABC, abstractmethod
from typing import List, Any
from .models import ValidationError

class ValidatorRule(ABC):
    @abstractmethod
    def validate(self, value: Any, row_index: int, field_name: str) -> List[ValidationError]:
        pass

class TypeRule(ValidatorRule):
    def __init__(self, expected_type: type):
        self.expected_type = expected_type

    def validate(self, value: Any, row_index: int, field_name: str) -> List[ValidationError]:
        if not isinstance(value, self.expected_type):
            return [ValidationError(row_index, field_name, f"Ожидался тип {self.expected_type.__name__}")]
        return []

class RangeRule(ValidatorRule):
    def __init__(self, min_val: float, max_val: float):
        self.min_val = min_val
        self.max_val = max_val

    def validate(self, value: Any, row_index: int, field_name: str) -> List[ValidationError]:
        errors = []
        if not isinstance(value, (int, float)):
            errors.append(ValidationError(row_index, field_name, "Значение не числовое, нельзя проверить диапазон"))
            return errors
        if value < self.min_val or value > self.max_val:
            errors.append(ValidationError(row_index, field_name, f"Значение вне диапазона [{self.min_val}, {self.max_val}]"))
        return errors

class RegexRule(ValidatorRule):
    def __init__(self, pattern: str):
        self.regex = re.compile(pattern)

    def validate(self, value: Any, row_index: int, field_name: str) -> List[ValidationError]:
        if not isinstance(value, str):
            return [ValidationError(row_index, field_name, "Ожидалась строка для проверки регулярным выражением")]
        if not self.regex.match(value):
            return [ValidationError(row_index, field_name, "Не соответствует шаблону")]
        return []