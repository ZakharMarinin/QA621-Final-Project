class InvalidConfigError(Exception):
    """Конфиг правил некорректен."""

class UnsupportedFormatError(Exception):
    """Неподдерживаемый формат входных данных (CSV/JSON)."""

class ValidationFailedError(Exception):
    """Валидация завершилась с ошибками."""