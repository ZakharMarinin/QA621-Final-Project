import argparse
import csv
import json
from pathlib import Path
from src.validator import Validator
from src.exceptions import UnsupportedFormatError
from src.models import RuleConfig
from src.utils import retry_on_error

@retry_on_error(max_retries=3)
def load_config(path: Path) -> list:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
        if not isinstance(data, list):
            from src.exceptions import InvalidConfigError
            raise InvalidConfigError("Конфиг должен быть списком правил.")
        return data

@retry_on_error(max_retries=3)
def load_data(path: Path):
    if path.suffix == ".csv":
        with path.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            return list(reader)
    elif path.suffix in (".json", ".jsonl"):
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict):
                data = [data]
            return data
    else:
        raise UnsupportedFormatError("Поддерживаются CSV и JSON")

def main():
    parser = argparse.ArgumentParser(description="Валидатор тестовых данных")
    parser.add_argument("--config", type=Path, required=True, help="Путь к config.json с правилами")
    parser.add_argument("--data", type=Path, required=True, help="Путь к данным (CSV или JSON)")
    parser.add_argument("--report", type=Path, default="report.json", help="Путь для сохранения отчёта")
    args = parser.parse_args()

    rules_raw = load_config(args.config)
    data = load_data(args.data)

    rules = [RuleConfig(**r) for r in rules_raw]
    validator = Validator(rules)

    result = validator.validate_data(data)

    report_dict = {
        "total_rows": result.total_rows,
        "error_count": len(result.errors),
        "errors": [e.__dict__ for e in result.errors],
        "warnings": result.warnings,
    }
    with args.report.open("w", encoding="utf-8") as f:
        json.dump(report_dict, f, ensure_ascii=False, indent=2)

    print(f"Валидация завершена. Всего строк: {result.total_rows}, ошибок: {len(result.errors)}")
    if result.errors:
        print("Первые 5 ошибок:")
        for e in result.errors[:5]:
            print(f"- Строка {e.row_index}, поле {e.field_name}: {e.message}")

if __name__ == "__main__":
    main()